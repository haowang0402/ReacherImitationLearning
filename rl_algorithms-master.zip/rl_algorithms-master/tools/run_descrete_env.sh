python run_lunarlander_v2.py --cfg-path ./configs/lunarlander_v2/dqn.py --off-render --log
python run_lunarlander_v2.py --cfg-path ./configs/lunarlander_v2/dqfd.py --off-render --log

python run_pong_no_frameskip_v4.py --cfg-path ./configs/pong_no_frameskip_v4/dqn.py --off-render --log
python run_pong_no_frameskip_v4.py --cfg-path ./configs/pong_no_frameskip_v4/dqn_resnet.py --off-render --log
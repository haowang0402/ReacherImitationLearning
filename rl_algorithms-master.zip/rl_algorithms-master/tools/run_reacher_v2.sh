python run_reacher_v2.py --cfg-path ./configs/reacher_v2/ddpg.py --off-render --log
python run_reacher_v2.py --cfg-path ./configs/reacher_v2/sac.py --off-render --log
python run_reacher_v2.py --cfg-path ./configs/reacher_v2/td3.py --off-render --log
python run_reacher_v2.py --cfg-path ./configs/reacher_v2/bc_ddpg.py --off-render --log
python run_reacher_v2.py --cfg-path ./configs/reacher_v2/bc_sac.py --off-render --log
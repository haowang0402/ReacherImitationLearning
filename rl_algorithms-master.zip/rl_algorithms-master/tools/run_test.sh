sh ./tools/run_lunarlander_continuous_v2.sh
sh ./tools/run_descrete_env.sh
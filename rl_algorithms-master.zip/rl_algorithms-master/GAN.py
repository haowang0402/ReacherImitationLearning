import torch
import torch.nn as nn
import gym
class Generator(torch.nn.Module):
    def __init__(self, n_features, output):
        self.n_features = n_features
        self.output = output
        self.hidden0 = nn.Sequential(nn.Linear(self.n_features, 256), nn.LeakyReLU(0.2))
        self.hidden1 = nn.Sequential(nn.Linear(256,1024), nn.LeakyReLU(0.2))
        self.out = nn.Sequential(nn.Linear(1024,self.output), nn.LeakyReLU(0.2))

    def forward(self,x):
        x += torch.randn(self.n_features)
        x  = self.hidden0(x)
        x  = self.hidden1(x)
        x  = self.out(x)
        return x

class Discriminator(torch.nn.Module):
    def __init__(self,n_features):
        self.n_features = n_features
        self.hidden0 = nn.Sequential(nn.Linear(self.n_features,256),nn.LeakyReLU(0.2))
        self.hidden1 = nn.Sequential(nn.Linear(256,1024),nn.LeakyReLU(0.2))
        self.hidden2 = nn.Sequential(nn.Linear(1024,128), nn.LeakyReLU(0.2))
        self.out = nn.Sequential(nn.Linear(128,1), nn.Sigmoid())

    def forward(self,x):
        x = self.hidden0(x)
        x = self.hidden1(x)
        x = self.hidden2(x)
        x = self.out(x)
        return x

dSource = Discriminator(12)
dTarget = Discriminator(11)
gSource = Generator(12)
gTarget = Generator(11)
criterion = nn.BCELoss()
gSourceOpt = torch.optim.Adam(gSource.parameter(),lr = 0.002)
gTargetOpt = torch.optim.Adam(gTarget.parameter(),lr = 0.002)
dSourceOpt = torch.optim.Adam(dSource.parameter(),lr = 0.002)
dTargetOpt = torch.optim.Adam(dTarget.parameter(),lr = 0.002)

def reset_grad():
    gSourceOpt.zero_grad()
    gTargetOpt.zero_grad()
    dSourceOpt.zero_grad()
    dTargetOpt.zero_gard()

reacher_v2 = gym.make("Reacher-v2")
reacher_v3 = gym.make("Reacher-v3")
